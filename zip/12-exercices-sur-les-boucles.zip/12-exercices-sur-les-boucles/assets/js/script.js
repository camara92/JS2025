// Les boucles (Exercice)
// Table de multiplication


for (let index = 0; index <= 12; index++) {
    console.log(`3 x ${index} = ${index+3}`);
}

/*var index = 0
while (index< 13) {
    console.log("3 x "+index+" = "+index*3);
    index++
}*/

/*var index = 0
do {
    // intruction
    console.log("3 x "+index+" = "+index*3);

    index++
} while (index < 13);
*/

