// Tableaux en JavaScript
/*
names.reverse()

names.join()

tab_string.split()

*/
var names = ["Alice", "Florent", "Jeane", "Mathieu"]

var firstnames = [...names, 'Nicolas','Marlène']