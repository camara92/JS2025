// Les structures conditionnelles
var age = prompt();
age = parseInt(age)



switch (age) {
    case 25:
        console.log("Vous avez 25 ans");
        break
    case 18:
        console.log("Vous avez 18 ans");
        break;
    case 15:
        console.log("Vous avez 15 ans");
        break;
}