// Les boucles

/*for (var index = 1; index <101 ; index++) {
   console.log("Tour de boucle n° "+index);
}*/

/*var index = 0;
while (index < 101) {
    console.log("Tour de boucle while N° "+index);
    index++;
}*/
//

var index = 0
do {
    console.log("Tour de boucle dowhile N° "+index);
    index++
} while (index < 0);
