// déclaration de variable
var age;

// Affectation
age = 45

var name;

name = "Hello 'world'"


var firstname = "TOUTOU"
console.log(firstname);