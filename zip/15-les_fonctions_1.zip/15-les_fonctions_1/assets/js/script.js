// Les fonctions en JavaScript

var saw_thanks = () => {
    console.log("Bienvenue dans notre première fonction");
    console.log("Bienvenue dans notre première fonction");
    console.log("Bienvenue dans notre première fonction");
}

var table_multiplication = () =>{
    for (let index = 0; index < 13; index++) {
        console.log(`3 x ${index} = ${index*3}`);
    }
}
