//console.log("Hello");

var hello = "Bonjour Mr/Mme";

var firstname = "Dupont"

var lastname = "Laure"

var age = 58;

var concat = hello+" "+firstname+" "+lastname+". Vous avez "+age+" ans";

console.log(concat);