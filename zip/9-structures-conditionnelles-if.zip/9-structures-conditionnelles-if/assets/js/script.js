// Les structures conditionnelles
var age = prompt();

if(age > 18){
    console.log("Vous êtes majeur");
}else if(age > 5){
    console.log("Vous êtes mineur");
}
// suite 